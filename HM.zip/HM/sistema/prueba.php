<?php

require_once "../conexion/conexion.php";
session_start();
if ($_SESSION['active'] != true) {
    session_destroy();
    header("location:../index.php");
}
$conexion = conexion();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../img/logo1.png" rel="shortcut icon" type="image/png">
    <title>HM</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/5d3f0049df.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="css/estilos.css">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php"><img src="../img/logo2.bmp" alt="" style="width:80px; height: 50px;"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php"> <i class="fas fa-home"></i> Inicio <span class="sr-only"></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="regEmp.php"> <i class="fas fa-user-edit"></i> Registrar empresa</a>
                    </li>
                    <li class="nav-item">
                        <a href="../conexion/salir.php" class="nav-link"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
                    </li>
                </ul>
                <!--<form class="form-inline my-2 my-lg-0" method="POST" action="buscar.php">
                    <input  class="mr-sm-2" type="search" placeholder="BUSCAR" aria-label="Search" name="nombre">
                    <button class="btn btn-outline-success my-sm-1 " type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
                    </form>-->
            </div>
        </div>
    </nav>
    <?php
    if (isset($_SESSION['msj'])) {
        $mensaje = $_SESSION['msj'];
    ?>
        <script>
            Swal.fire({
                position: 'top-center',
                icon: 'success',
                title: '<?php echo $mensaje ?>',
                showConfirmButton: true,
                timer: 3500
            })
        </script>
    <?php
        unset($_SESSION['msj']);
    } else if (isset($_SESSION['msg'])) {
        $msg = $_SESSION['msg'];
    ?>
        <script>
            Swal.fire({
                position: 'top-center',
                icon: 'error',
                title: '<?php echo $msg ?>',
                showConfirmButton: true,
                timer: 3500
            })
        </script>
    <?php
        unset($_SESSION['msg']);
    }
    ?>
    <div class="container-fluid">
        <form action="agregar/exc.php" method="POST" enctype="multipart/form-data">

            <div class="row">
                <h4 style="text-align: center; color:white;" class="bg-dark"><i class="fa-sharp fa-solid fa-people-roof"></i> Familia de productos a certificar</h4>
                <div class="col-md-12">
                    <div class="file-input">
                        <div class="col-sm-12">
                            <input name="dataCliente" id="file-input" class="file-input__input" type="file" accept="text/csv" capture="environment"></input>
                        </div>
                    </div>
                </div>

            </div>


            
            <a href="index.php" class="btn btn-danger"><i class="fas fa-undo"></i> Regresar</a>
            <button type="submit" class="btn btn-success"><i class="fas fa-check-circle"></i> Registrar</button>
        </form>
        <div class="col-md-6">
            <div class="form-group row">
                <strong><label for="" class="col-sm-6 col-form-label"></label></strong>
                <div class="col-sm-12">
                </div>
            </div>
        </div>
    </div>
    <script src="segui/agreg.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <script src="sweetalert2.all.min.js"></script>
</body>

</html>