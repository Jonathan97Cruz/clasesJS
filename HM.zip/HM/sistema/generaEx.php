
<?php
require_once "../conexion/conexion.php";
session_start();
if ($_SESSION['active'] != true) {
    session_destroy();
    header("location:../index.php");
}
$conexion = conexion();

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="archivo.csv"');


$cons = mysqli_query($conexion, "SELECT idPrue, excel FROM prex WHERE idPrue = '6' ");
$con = mysqli_num_rows($cons);
if ($con > 0) {
    while ($a = mysqli_fetch_array($cons)) {
        $archivoE = $a['excel'];
        $binario = base64_decode($archivoE);

    echo $binario;
    }
}

