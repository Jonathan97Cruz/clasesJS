<nav class="navbar navbar-expand-lg navbar-dark bg-dark" >
    <a class="navbar-brand" href="index.php"><img src="../img/logo2.bmp" alt="" style="width:80px; height: 50px;"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent" >
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php"> <i class="fas fa-home"></i> Inicio <span class="sr-only"></span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="regEmp.php"> <i class="fas fa-user-edit"></i> Registrar empresa</a>
      </li>
      <li class="nav-item-active">
        <a href="../conexion/salir.php" class="nav-link"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
      </li>
    </ul>
    <!--<form class="form-inline my-2 my-lg-0" method="POST" action="buscar.php">
      <input  class="mr-sm-2" type="search" placeholder="BUSCAR" aria-label="Search" name="nombre">
      <button class="btn btn-outline-success my-sm-1 " type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>-->

  </div>            
</nav>