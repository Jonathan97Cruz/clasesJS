<?php

require_once "../../conexion/conexion.php";
session_start();
if($_SESSION['active'] != true){
    session_destroy();
    header("location:../../index.php");
}
$conexion = conexion();

$tipo = $_FILES['dataCliente']['type'];
$tamanio = $_FILES['dataCliente']['size'];
$archTemp = $_FILES['dataCliente']['tmp_name'];
$lineas = file($archTemp);

$i = 0;

foreach($lineas as $linea){
    $cantReg = count($lineas);
    $cantRegAgre = ($cantReg -1);//quita la primer columna
    if($i != 0){
        $datos = explode(",",$linea);
        $usuario = !empty($datos[0]) ? ($datos[0]) : ''; 
        $actuales = !empty($datos[1]) ? ($datos[1]) : '';
        $fecha = !empty($datos[2]) ? ($datos[2]) : '';


        $sql = mysqli_query($conexion,"INSERT INTO `prex`(`usuario`,`actuales`,`fecha`)
                            VALUES ('$usuario','$actuales','$fecha')" );
        
        
    }
    //echo '<div><br><h2>Por favor ingresa un archivo de tipo CSV.</h2><br><a href="../prueba.php">Regresar a la página anterior </a>  </div>';
    $i++;
    if($sql == false){
        $_SESSION['msg'] = 'Por favor ingresa un archivo de tipo CSV.';
        header('location:../prueba.php');
    }else{
        $_SESSION['msj'] = 'Agregado correctamente';
        header('location:../index.php');
    }
}



/*$handle = fopen($archi, "r");
$data = array();

while( ($row = fgetcsv($handle,1000,",")) != false){
    if($i == 0){
        $i++;
        continue;
    }
    $data[] = $row;
}
fclose($handle);
$file_data = serialize($data);

$sql = mysqli_query($conexion,"INSERT INTO `prex`(`excel`)
                            VALUES ('$file_data')" );
if($sql == true){
    $_SESSION['msj'] = 'Agregado correctamente';
    header('location:../index.php');
}else{
    $_SESSION['msg'] = 'No se pudo agregar';
    header('location:../prueba.php');
}*/


/*$file = fopen($archi['tmp_name'], 'r');
$excel_data = array();
while( ($row = fgetcsv($file)) !== false ){
    $excel_data[] = $row;
}
fclose($file);

$excel_data_str = '';
foreach($excel_data as $row){
    $excel_data_str .= implode(',',$row) . ';';
}

$excel_data_st = mysqli_real_escape_string($conexion,$excel_data_str);

$sql = mysqli_query($conexion,"INSERT INTO `prex`(`empresa`, `razon`, `estatus`, `excel`)
                            VALUES ('$empresa','$razon','$estProc','$excel_data_st')" );
if($sql == true){
    $_SESSION['msj'] = 'Agregado correctamente';
    header('location:../index.php');
}else{
    $_SESSION['msg'] = 'No se pudo agregar';
    header('location:../prueba.php');
}*/                            

?>