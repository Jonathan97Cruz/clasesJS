<?php

require_once "../../conexion/conexion.php";
session_start();
if($_SESSION['active'] != true){
    session_destroy();
    header("location:../../index.php");
}
$conexion = conexion();

$empresa = $_POST['empresa'];
$razon = $_POST['razon'];
$contacto = $_POST['contacto'];
$correo = $_POST['correo'];
$telefono = $_POST['telefono'];
$origen = $_POST['origen'];
$direccion = $_POST['direccion'];
$direP = $_POST['direP'];
$fecha = $_POST['fecha'];
$solici = $_POST['solici'];
$revi = $_POST['revi'];
$visi = $_POST['visi'];
$estProc = $_POST['estProc'];

//Familia de productos
$fami = $_POST['fami'];
$pueF = $_POST['pueF'];
$modelo = $_POST['modelo'];


//Tramitador t1
$tr1 = $_POST['tr1'];
$pu1 = $_POST['pu1'];
$te1 = $_POST['te1'];
$co1 = $_POST['co1'];

//contrato
$acta = $_POST['acta'];
$poder = $_POST['poder'];
$situa = $_POST['situacion'];
$repres = $_POST['repre'];
$compro = $_POST['compro'];
$trammi = $_POST['trami'];
$idTram = $_POST['idTram'];
$idTest = $_POST['idTest'];
$idTestD = $_POST['idTestD'];
    
//Evaluación
$solSer = $_POST['solSer'];
$solSerO = $_POST['solSerO'];
$tablaM = $_POST['tablaM'];
$tablaMO = $_POST['tablaMO'];
$evideC = $_POST['evideC'];
$evideCO = $_POST['evideCO'];
$cartaS = $_POST['cartaS'];
$cartaSO = $_POST['cartaSO'];
$cartaM = $_POST['cartaM'];
$cartaMO = $_POST['cartaMO'];
$proceP = $_POST['proceP'];
$procePO = $_POST['procePO'];
$cartaP = $_POST['cartaP'];
$cartaPO = $_POST['cartaPO'];
$marcaP = $_POST['marcaP'];
$marcaPO = $_POST['marcaPO'];
$contraI = $_POST['contraI'];
$contraIO = $_POST['contraIO'];
$otroD = $_POST['otroD'];
$otroDO = $_POST['otroDO'];

//Evidencia de compra de materia prima t2
$mtu = $_POST['mtu'];
$ftu = $_POST['ftu'];
$pvu = $_POST['pvu'];
$ctu = $_POST['ctu'];
$pou = $_POST['pou'];
$obu = $_POST['obu'];
//Revisión de prototipos t3
$rpu = $_POST['rpu'];
$rlu = $_POST['rlu'];
$rau = $_POST['rau'];
$rmu = $_POST['rmu'];
$rluu = $_POST['rluu'];
$rou = $_POST['rou'];
//Carta supuesto a certificar
$carc = $_POST['carc'];
$carco = $_POST['carco'];
$camap = $_POST['camap'];
$camapo = $_POST['camapo'];
$propr = $_POST['propr'];
$propro = $_POST['propro'];
$pmarcp = $_POST['pmarcp'];
$pmarcpo = $_POST['pmarcp'];

$codigo_aleatorio = substr(md5(rand()), 0, 4);
while (!ctype_alnum($codigo_aleatorio)) {
    $codigo_aleatorio = substr(md5(rand()), 0, 4);
}


$query = mysqli_query($conexion,"INSERT INTO `registro`(`nomEmp`, `razonSocial`, `contacto`, `correo`, `telefono`, `origen`, `direccion`, `direcProd`, `fecContrato`, `fecSolicitud`, `fecRevision`, `fecVisita`,`estProc`,`codAle`)
                                VALUES ('$empresa','$razon','$contacto','$correo','$telefono','$origen','$direccion','$tr1','$pu1',
                                        '$te1','$co1','$direP','$fecha','$solici','$revi','$visi','$estProc','$codigo_aleatorio')");
                                        
if($query == true){
    $cont = mysqli_query($conexion,"INSERT INTO `contrato`(`acta`, `poder`, `situa`, `repres`, `compro`, `trammi`, `idTram`, `idTest`, `idTestD`, `codAle`) 
                                VALUES ('$acta','$poder','$situa','$repres','$compro','$trammi','$idTram','$idTest','$idTestD','$codigo_aleatorio')");
    if($cont == true){
        $eva = mysqli_query($conexion,"INSERT INTO `evalua`(`solSer`, `solSerO`, `tablaM`, `tablaMO`, `evideC`, `evideCO`, `cartaS`, `cartaSO`,
                                `cartaM`, `cartaMO`, `proceP`, `procePO`, `cartaP`, `cartaPO`, `marcaP`, `marcaPO`, `contraI`, `contraIO`, `otroD`, `otroDO`, `codAle`)
                                VALUES ('$solSer','$solSerO','$tablaM','$tablaMO','$evideC','$evideCO','$cartaS','$cartaSO','$cartaM','$cartaMO','$proceP','$procePO',
                                '$cartaP','$cartaPO','$marcaP','$marcaPO','$contraI','$contraIO','$otroD','$otroDO','$codigo_aleatorio')");
        if($eva == true){
            $cert = mysqli_query($conexion, "INSERT INTO `casupu`(`carc`, `carco`, `camap`, `camapo`, `propr`, `propro`, `pmarcp`, `pmarcpo`, `codAle`) 
            VALUES ('$carc','$carco','$camap','$camapo','$propr','$propro','$pmarcp','$pmarcpo','$codigo_aleatorio')" );
            if($cert == true){
                for($i=0; $i < count($tr1); $i++){
                    $trami = mysqli_query($conexion,"INSERT INTO `tramitador`(`nombre`, `puesto`, `telefono`, `correo`,`codAle`) 
                                    VALUES ('$tr1[$i]','$pu1[$i]','$te1[$i]','$co1[$i]','$codigo_aleatorio')" );
                }
                if($trami == true){
                    for($u=0; $u < count($mtu); $u++){
                        $mate = mysqli_query($conexion,"INSERT INTO `evcomp`(`matPri`, `fact`, `provee`, `carta`, `proveed`, `obs`, `codAle`) 
                                                    VALUES ('$mtu[$u]','$ftu[$u]','$pvu[$u]','$ctu[$u]','$pou[$u]','$obu[$u]','$codigo_aleatorio') ");
                    }
                    if($mate == true){
                        for($b=0; $b < count($rpu); $b++){
                            $pr = mysqli_query($conexion,"INSERT INTO `reproto`(`prod`, `lugar`, `ancho`, `medAct`, `medCor`, `obs`, `codAle`) 
                                                        VALUES ('$rpu[$b]','$rlu[$b]','$rau[$b]','$rmu[$b]','$rluu[$b]','$rou[$b]','$codigo_aleatorio') ");
                        }
                        if($pr == true){
                            for($a=0; $a < count($fami); $a++){
                                $fa = mysqli_query($conexion,"INSERT INTO `famiprod`(`familiaPC`, `puestoPC`, `modelosPC`, `codAle`) 
                                                            VALUES ('$fami[$a]','$pueF[$a]','$modelo[$a]','$codigo_aleatorio')");
                            }
                            $_SESSION['msj'] = "Empresa agregada con exito";
                            header("location:../index.php");
                        }
                    }
                }
            }
        }
    }
}else{
    $_SESSION['msg'] = "Error al agregar" ;
    header('location:../regEmp.php');
}     

?>