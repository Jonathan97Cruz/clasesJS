<?php
require_once "../../conexion/conexion.php";
session_start();
if($_SESSION['active'] != true){
    session_destroy();
    header("location:../../index.php");
}
$conexion = conexion();
$idS = $_POST['idSe'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="../../img/logo1.png" rel="shortcut icon" type="image/png">
        <title>HM</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <script src="https://kit.fontawesome.com/5d3f0049df.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="../css/estilos.css">

    </head>
    <body>

        <nav class="navbar navbar-expand-lg navbar-dark bg-dark" >
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php"><img src="../../img/logo2.bmp" alt="" style="width:80px; height: 50px;"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" href="../index.php"> <i class="fas fa-home"></i> Inicio <span class="sr-only"></span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../regEmp.php"> <i class="fas fa-user-edit"></i> Registrar empresa</a>
                        </li>
                        <li class="nav-item">
                            <a href="../../conexion/salir.php" class="nav-link"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
                        </li>
                    </ul>
                    <!--<form class="form-inline my-2 my-lg-0" method="POST" action="buscar.php">
                    <input  class="mr-sm-2" type="search" placeholder="BUSCAR" aria-label="Search" name="nombre">
                    <button class="btn btn-outline-success my-sm-1 " type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
                    </form>-->
                </div>
            </div>            
        </nav>
        <div class="container-fluid">
            
                <div class="row">
                    <h2 class="fw-bold">Datos de la empresa</h2>
                    <h4 style="text-align: center; color:white" class="bg-dark"><i class="fa-sharp fa-solid fa-hotel"></i> Información de la empresa</h4>
                    <?php
                        $query = mysqli_query($conexion,"SELECT * FROM registro WHERE idR = '$idS' ");
                        $quer = mysqli_num_rows($query);
                        if($quer > 0){
                            while($a = mysqli_fetch_array($query)){
                                $idR = $a['idR'];
                                $empresa = $a['nomEmp'];
                                $razon = $a['razonSocial'];
                                $contacto = $a['contacto'];
                                $correo = $a['correo'];
                                $telefono = $a['telefono'];
                                $origen = $a['origen'];
                                $direccion = $a['direccion'];
                                $direP = $a['direcProd'];
                                $fecha = $a['fecContrato'];
                                $solici = $a['fecSolicitud'];
                                $revi = $a['fecRevision'];
                                $visi = $a['fecVisita'];
                                $estProc = $a['estProc'];
                                $codAle = $a['codAle'];
                            }
                        }
                    ?>
                    <div class="col-md-4">
                        <div class="form-group row">
                            <strong><label for="" class="col-sm-6 col-form-label"><i class="fa-sharp fa-solid fa-dice-d20"></i> Nombre de la empresa*</label></strong>
                            <div class="col-sm-12">
                                <input disabled id="empresa" name="empresa" type="text" class="form-control" placeholder="Nombre de la empresa" value="<?php echo $empresa ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group row">
                            <strong><label for="" class="col-sm-6 col-form-label"><i class="fas fa-file-invoice"></i> Razón social*</label></strong>
                            <div class="col-sm-12">
                                <input disabled id="razon" name="razon" type="text" class="form-control" placeholder="Razón social" value="<?php echo $razon ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group row">
                            <strong><label for="" class="col-sm-6 col-form-label"><i class="fas fa-id-badge"></i> Contacto</label></strong>
                            <div class="col-sm-12">
                                <input disabled id="contacto" name="contacto" type="text" class="form-control" value="<?php echo $contacto?>" placeholder="Contacto">
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group row">
                            <strong><label for="" class="col-sm-6 col-form-label"><i class="fas fa-envelope-square"></i> Correo</label></strong>
                            <div class="col-sm-12">
                                <input disabled type="text" id="correo" name="correo" placeholder="Correo" value="<?php echo $correo ?>" class="form-control">
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group row">
                            <strong><label for="" class="col-sm-6 col-form-label"><i class="fas fa-mobile-android-alt"></i> Teléfono</label></strong>
                            <div class="col-sm-12">
                                <input disabled type="text" class="form-control" id="telefono" name="telefono" value="<?php echo $telefono ?>" placeholder="Telefono">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group row">
                            <strong><label for="" class="col-sm-6 col-form-label"><i class="fas fa-headset"></i> Origen</label></strong>
                            <div class="col-sm-12">
                                <select name="origen" id="origen" class="form-select" disabled>
                                    <option value="<?php echo $origen ?>"><?php echo $origen ?></option>
                                    <option value="Llamada">Llamada</option>
                                    <option value="Correo">Correo</option>
                                    <option value="Redes">Redes</option>
                                    <option value="Recomendación">Recomendación</option>
                                    <option value="Ing. Marco Antonio Heredia Duvignau">Ing. Marco Antonio Heredia Duvignau</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group row">
                            <strong><label for="" class="col-sm-6 col-form-label"><i class="fas fa-location"></i> Dirección</label></strong>
                            <div class="col-sm-12">
                                <input disabled type="text" id="direccion" name="direccion" placeholder="Dirección" class="form-control" value="<?php echo $direccion ?>">
                            </div>
                        </div>
                    </div>
                </div><br>

                <div class="row"><!--Informacion del tramitador-->
                    <?php
                        $int = mysqli_query($conexion,"SELECT * FROM tramitador WHERE codAle = '$codAle' ");
                        $in = mysqli_num_rows($int);
                        if($in > 0){
                            echo '
                            <h4 style="text-align: center; color:white;" class="bg-dark"><i class="fas fa-address-book"></i> Información del tramitador</h4>
                            <table class="table" id="tramita">
                                <thead class="thead-primary">
                                    <tr class="table-dark">
                                        <th style="text-align: center;"><i class="fas fa-child"></i> Nombre del tramitador</th>
                                        <th style="text-align: center;"><i class="fas fa-suitcase-rolling"></i> Puesto</th>
                                        <th style="text-align: center;"><i class="fas fa-mobile-android-alt"></i> Teléfono</th>
                                        <th style="text-align: center;"><i class="fas fa-envelope-square"></i> Correo</th>
                                    </tr>
                                </thead>
                                <tbody>
                            ';
                            while($a = mysqli_fetch_array($int)){ ?>               
                                <tr>
                                    <td>
                                        <div class="col-md-12">
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                <input value="<?php echo $a['idTram'] ?>" type="hidden" class="form-control" name="idTram[]">
                                                <input value="<?php echo $a['nombre'] ?>" type="text" class="form-control" id="tr1" name="tr1[]" placeholder="Tramitador" disabled>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><!--Puesto-->
                                        <div class="col-md-12">
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                <input value="<?php echo $a['puesto'] ?>" type="text" class="form-control" id="pu1" name="pu1[]" placeholder="Puesto" disabled>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><!--Telefono-->
                                        <div class="col-md-12">
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                <input value="<?php echo $a['telefono'] ?>" type="text" class="form-control" id="te1" name="te1[]" placeholder="Telefono" disabled>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><!--correo-->
                                    <div class="col-md-12">
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                <input value="<?php echo $a['correo'] ?>" type="text" class="form-control" id="co1" name="co1[]" placeholder="Correo" disabled>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                
                            <?php 
                            } 
                            echo '
                                </tbody>
                            </table>
                            ';
                        }
                    ?>
                </div>

                <div class="row">
                    <?php
                        $fam = mysqli_query($conexion,"SELECT * FROM famiprod WHERE codAle = '$codAle'");
                        $fa = mysqli_num_rows($fam);
                        if($fa > 0){
                            echo '
                            <h4 style="text-align: center; color:white" class="bg-dark"><i class="fa-sharp fa-solid fa-people-roof"></i> Familia de productos a certificar</h4>
                            <table class="table" id="famPr">
                                <thead>
                                    <tr class="table-dark">
                                        <td class="cent"><i class="fa-sharp fa-solid fa-universal-access"></i> Familia</td>
                                        <td class="cent"><i class="fas fa-suitcase-rolling"></i> Supuesto</td>
                                        <td class="cent"><i class="fas fa-sitemap"></i> Modelos</td>
                                    </tr>
                                </thead>
                                <tbody>
                            ';
                            while($a = mysqli_fetch_array($fam)){
                                $fami = $a['familiaPC'];
                                $puesto = $a['puestoPC'];
                                $modelos = $a['modelosPC'];
                                
                                echo '
                                <tr>
                                    <td>
                                        <div class="col-md-12">
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                    <input type="text" class="form-control" id="fami[]" name="fami[]" disabled value="'.$fami.'">
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="col-md-12">
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                    <select name="pueF[]" id="pueF[]" class="form-select" disabled>
                                                        <option value="'.$puesto.'">'.$puesto.'</option>
                                                        <option value="Gerente">Gerente</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="col-md-12">
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                    <textarea disabled name="modelo[]" id="modelo[]" class="form-control" rows="1" placeholder="Ingresa un modelo ">'.$modelos.'</textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr> 
                                ';
                            }
                            echo '
                                </tbody>
                            </table>
                            ';
                        }
                        
                    ?>
                </div><br>
                <form action="seg.php" method="POST">
                <div class="row">
                    <input type="hidden" name="idEmpre" value="<?php echo $idR ?>">
                    
                    <h4 style="text-align: center; color:white;" class="bg-dark"><i class="fas fa-file-contract"></i> Contrato</h4>
                    <?php
                        $c = mysqli_query($conexion,"SELECT * FROM contrato WHERE codAle = '$codAle' ");
                        $oc = mysqli_num_rows($c);
                        if($oc > 0){
                            while($noc = mysqli_fetch_array($c)){
                                $idContra = $noc['idContra'];
                                $ac = $noc['acta'];
                                $po = $noc['poder'];
                                $si = $noc['situa'];
                                $rep = $noc['repres'];
                                $com = $noc['compro'];
                                $tramm = $noc['trammi'];
                                $idTram = $noc['idTram'];
                                $idTest = $noc['idTest'];
                                $idTestD = $noc['idTestD'];
                            }
                        }else{
                            echo 'no hay datos';
                        }
                    ?>
                    <div class="col-md-4">
                        <div class="form-group row">
                            <input type="hidden" class="form-control" name="idContra" value="<?php echo $idContra ?>">
                            <strong><label for="" class="col-form-label col-sm-6"><i class="fas fa-file-invoice"></i> Acta constitutiva</label></strong>
                            <div class="col-sm-12">
                                <select name="acta" id="acta" class="form-select">
                                    <option value="<?php echo $ac; ?>"><?php echo $ac; ?></option>
                                    <option value="Entregado">Entregado</option>
                                    <option value="Falta">Falta</option>
                                    <option value="NA">NA</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group row">
                            <strong><label for="" class="col-form-label col-sm-6"><i class="fas fa-file-signature"></i> Poder Notarial</label></strong>
                            <div class="col-sm-12">
                                <select name="poder" id="poder" class="form-select" >
                                    <option value="<?php echo $po; ?>"><?php echo $po; ?></option>
                                    <option value="Entregado">Entregado</option>
                                    <option value="Falta">Falta</option>
                                    <option value="NA">NA</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group row">
                            <strong><label for="" class="col-form-label col-sm-6"><i class="fas fa-file"></i>Constancia de Situación Fiscal</label></strong>
                            <div class="col-sm-12">
                                <select name="situacion" id="situacion" class="form-select">
                                    <option value="<?php echo $si ?>"><?php echo $si ?></option>
                                    <option value="Entregado">Entregado</option>
                                    <option value="Falta">Falta</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group row">
                            <strong><label for="" class="col-form-label col-sm-6"><i class="fa-sharp fa-solid fa-id-card-clip"></i> ID Representante legal</label></strong>
                            <div class="col-sm-12">
                                <select name="repre" id="repre" class="form-select">
                                    <option value="<?php echo $rep ?>"><?php echo $rep ?></option>
                                    <option value="Entregado">Entregado</option>
                                    <option value="Falta">Falta</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group row">
                            <strong><label for="" class="col-form-label col-sm-6"><i class="fas fa-file-invoice"></i> Comprobante de domicilio</label></strong>
                            <div class="col-sm-12">
                                <select name="compro" id="compro" class="form-select">
                                    <option value="<?php echo $com ?>"><?php echo $com ?></option>
                                    <option value="Entregado">Entregado</option>
                                    <option value="Falta">Falta</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group row">
                            <strong><label for="" class="col-form-label col-sm-6"><i class="fa-sharp fa-solid fa-envelope-open-text"></i> Carta de tramitadores</label></strong>
                            <div class="col-sm-12">
                                <select name="trami" id="trami" class="form-select">
                                    <option value="<?php echo $tramm ?>"><?php echo $tramm ?></option>
                                    <option value="Entregado">Entregado</option>
                                    <option value="Falta">Falta</option>
                                    <option value="NA">NA</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group row">
                            <strong><label for="" class="col-form-label col-sm-6"><i class="fa-sharp fa-solid fa-id-card-clip"></i> ID de tramitador(es)</label></strong>
                            <div class="col-sm-12">
                                <select name="idTram" id="idTram" class="form-select">
                                    <option value="<?php echo $idTram ?>"><?php echo $idTram ?></option>
                                    <option value="Entregado">Entregado</option>
                                    <option value="Falta">Falta</option>
                                    <option value="NA">NA</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group row">
                            <strong><label for="" class="col-form-label col-sm-6"><i class="fa-sharp fa-solid fa-id-card-clip"></i> ID de testigo 1</label></strong>
                            <div class="col-sm-12">
                                <select name="idTest" id="idTest" class="form-select">
                                    <option value="<?php echo $idTest ?>"><?php echo $idTest ?></option>
                                    <option value="Entregado">Entregado</option>
                                    <option value="Falta">Falta</option>
                                    <option value="NA">NA</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group row">
                            <strong><label for="" class="col-form-label col-sm-6"><i class="fa-sharp fa-solid fa-id-card-clip"></i> ID de testigo 2</label></strong>
                            <div class="col-sm-12">
                                <select name="idTestD" id="idTestD" class="form-select">
                                    <option value="<?php echo $idTestD ?>"><?php echo $idTestD ?></option>
                                    <option value="Entregado">Entregado</option>
                                    <option value="Falta">Falta</option>
                                    <option value="NA">NA</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group row">
                            <strong><label for="" class="col-sm-6 col-form-label"><i class="fas fa-calendar-day"></i> Fecha de contrato</label></strong>
                            <div class="col-sm-12">
                                <input type="date" class="form-control" id="fecha" name="fecha" value="<?php echo $fecha?>">
                            </div>
                        </div>
                    </div>
                </div><br>
                <div class="row">
                    <h4  style="text-align: center; color:white;" class="bg-dark"><i class="fa-sharp fa-solid fa-check-double"></i> Evaluación</h4>
                    <table class="table">
                        <?php 
                            $mb = mysqli_query($conexion,"SELECT * FROM evalua WHERE codAle = '$codAle'");
                            $mbb = mysqli_num_rows($mb);
                            if($mbb > 0){
                                while($bm = mysqli_fetch_array($mb)){
                                    $idEvalua = $bm['idEvalua'];
                                    $res = $bm['solSer'];
                                    $oser = $bm['solSerO'];
                                    $mal = $bm['tablaM']; 
                                    $malo = $bm['tablaMO'];
                                    $ced = $bm['evideC'];
                                    $oce = $bm['evideCO'];
                                    $sat = $bm['cartaS'];
                                    $osa = $bm['cartaSO'];
                                    $mat = $bm['cartaM'];
                                    $omat = $bm['cartaMO'];
                                    $pec = $bm['proceP'];
                                    $ope = $bm['procePO'];
                                    $pat = $bm['cartaP'];
                                    $opat = $bm['cartaPO'];
                                    $pac = $bm['marcaP'];
                                    $opa = $bm['marcaPO'];
                                    $iar = $bm['contraI'];
                                    $oia = $bm['contraIO'];
                                    $dor = $bm['otroD'];
                                    $odo = $bm['otroDO'];
                                }
                            } 
                        ?> 
                        <tbody>
                            <tr>
                                <td><!--Documentos-->
                                    <div>
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <input type="hidden" name="idEvalua" value="<?php echo $idEvalua ?>">
                                                <strong><label for="" class="col-form-label col-sm-12"><i class="fas fa-file-invoice"></i> Solicitud(es) de servicios</label></strong>
                                            </div>
                                            <div class="col-sm-4">
                                                <select name="solSer" id="solSer" class="form-select">
                                                    <option value="<?php echo $res ?>"><?php echo $res ?></option>
                                                    <option value="Entregado">Entregado</option>
                                                    <option value="Falta">Falta</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <textarea name="solSerO" id="solSerO"  rows="1" class="form-control" placeholder="Observaciones"><?php echo $oser ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div>
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <strong><label for="" class="col-form-label col-sm-12"><i class="fa-sharp fa-solid fa-receipt"></i> Tabla de materiales</label></strong>
                                            </div>
                                            <div class="col-sm-4">
                                                <select name="tablaM" id="tablaM" class="form-select">
                                                    <option value="<?php echo $mal ?>"><?php echo $mal ?></option>
                                                    <option value="Entregado">Entregado</option>
                                                    <option value="En revisión">En revisión</option>
                                                    <option value="Falta">Falta</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <textarea name="tablaMO" id="tablaMO"  rows="1" class="form-control" placeholder="Observaciones"><?php echo $malo ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td >
                                    <div>
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <strong><label for="" class="col-form-label col-sm-12"><i class="fa-sharp fa-solid fa-biohazard"></i> Evidencia de compra de materia prima</label></strong>
                                            </div>
                                            <div class="col-sm-4">
                                                <select name="evideC" id="evideC" class="form-select">
                                                    <option value="<?php echo $ced ?>"><?php echo $ced ?></option>
                                                    <option value="Entregado">Entregado</option>
                                                    <option value="En revisión">En revisión</option>
                                                    <option value="Falta">Falta</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <textarea name="evideCO" id="evideCO"  rows="1" class="form-control" placeholder="Observaciones"><?php echo $oce ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td >
                                    <div>
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <strong><label for="" class="col-form-label col-sm-12"><i class="fa-sharp fa-solid fa-envelope-open-text"></i> Carta supuesto a certificar</label></strong>
                                            </div>
                                            <div class="col-sm-4">
                                                <select name="cartaS" id="cartaS" class="form-select">
                                                    <option value="<?php echo $sat ?>"><?php echo $sat ?></option>
                                                    <option value="Entregado">Entregado</option>
                                                    <option value="En revisión">En revisión</option>
                                                    <option value="Falta">Falta</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <textarea name="cartaSO" id="cartaSO"  rows="1" class="form-control" placeholder="Observaciones"><?php echo $osa ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div>
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <strong><label for="" class="col-form-label col-sm-12"><i class="fa-sharp fa-solid fa-envelope-open-text"></i> Carta marcado y lugar de uso de logotipo</label></strong>
                                            </div>
                                            <div class="col-sm-4">
                                                <select name="cartaM" id="cartaM" class="form-select">
                                                    <option value="<?php echo $mat ?>"><?php echo $mat ?></option>
                                                    <option value="Entregado">Entregado</option>
                                                    <option value="En revisión">En revisión</option>
                                                    <option value="Falta">Falta</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <textarea name="cartaMO" id="cartaMO"  rows="1" class="form-control" placeholder="Observaciones"><?php echo $omat ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td >
                                    <div>
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <strong><label for="" class="col-form-label col-sm-12"><i class="fa-sharp fa-solid fa-spinner"></i> Proceso de producción detallado</label></strong>
                                            </div>
                                            <div class="col-sm-4">
                                                <select name="proceP" id="proceP" class="form-select">
                                                    <option value="<?php echo $pec ?>"><?php echo $pec ?></option>
                                                    <option value="Entregado">Entregado</option>
                                                    <option value="En revisión">En revisión</option>
                                                    <option value="Falta">Falta</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <textarea name="procePO" id="procePO"  rows="1" class="form-control" placeholder="Observaciones"><?php echo $ope ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td >
                                    <div>
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <strong><label for="" class="col-form-label col-sm-12"><i class="fa-sharp fa-solid fa-envelope-open-text"></i> Cartas de proveedores</label></strong>
                                            </div>
                                            <div class="col-sm-4">
                                                <select name="cartaP" id="cartaP" class="form-select">
                                                    <option value="<?php echo $pat ?>"><?php echo $pat ?></option>
                                                    <option value="Entregado">Entregado</option>
                                                    <option value="En revisión">En revisión</option>
                                                    <option value="Falta">Falta</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <textarea name="cartaPO" id="cartaPO"  rows="1" class="form-control" placeholder="Observaciones"><?php echo $opat ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td >
                                    <div>
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <strong><label for="" class="col-form-label col-sm-12"><i class="fa-sharp fa-solid fa-pen-to-square"></i> Marcados prototipo</label></strong>
                                            </div>
                                            <div class="col-sm-4">
                                                <select name="marcaP" id="marcaP" class="form-select">
                                                    <option value="<?php echo $pac ?>"><?php echo $pac ?></option>
                                                    <option value="Entregado">Entregado</option>
                                                    <option value="En revisión">En revisión</option>
                                                    <option value="Falta">Falta</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <textarea name="marcaPO" id="marcaPO"  rows="1" class="form-control" placeholder="Observaciones"><?php echo $opa ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td >
                                    <div>
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <strong><label for="" class="col-form-label col-sm-12"><i class="fas fa-file-contract"></i> Contrato o información de maquila</label></strong>
                                            </div>
                                            <div class="col-sm-4">
                                                <select name="contraI" id="contraI" class="form-select">
                                                    <option value="<?php echo $iar ?>"><?php echo $iar ?></option>
                                                    <option value="Entregado">Entregado</option>
                                                    <option value="Falta">Falta</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <textarea name="contraIO" id="contraIO"  rows="1" class="form-control" placeholder="Observaciones"><?php echo $oia ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div>
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <strong><label for="" class="col-form-label col-sm-12"><i class="fa-sharp fa-solid fa-bullseye"></i> Otros documentos</label></strong>
                                            </div>
                                            <div class="col-sm-4">
                                                <select name="otroD" id="otroD" class="form-select">
                                                    <option value="<?php echo $dor ?>"><?php echo $dor ?></option>
                                                    <option value="Entregado">Entregado</option>
                                                    <option value="Falta">Falta</option>
                                                    <option value="NA">NA</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <textarea name="otroDO" id="otroDO"  rows="1" class="form-control" placeholder="Observaciones"><?php echo $odo ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div>
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <strong><label for="" class="col-sm-6 col-form-label"><i class="fas fa-calendar-day"></i> Fecha de solicitud (Inicio de servicio)</label></strong>
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="date" class="form-control" id="solici" name="solici" value="<?php echo $solici ?>">
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <br>
                </div>
                <div class="row">
                    <?php
                        $evide = mysqli_query($conexion,"SELECT * FROM evcomp WHERE codAle = '$codAle'");
                        $ediv = mysqli_num_rows($evide);
                        if($ediv > 0 ){
                            echo '
                            <h4 style="text-align: center; color:white;" class="bg-dark "><i class="fa-sharp fa-solid fa-boxes-stacked"></i> Evidencia de compra de materia prima</h4>
                            <table class="table" id="eviden">
                                <thead class="thead-dark">
                                    <tr class="table-dark">
                                        <th style="text-align: center"><i class="fa-sharp fa-solid fa-box"></i> Materia prima</th>
                                        <th style="text-align: center"><i class="fas fa-file-signature"></i> Factura</th>
                                        <th style="text-align: center"><i class="fa-sharp fa-solid fa-boxes-packing"></i> Proveedor</th>
                                        <th style="text-align: center"><i class="fa-sharp fa-solid fa-envelope-open-text"></i> Carta</th>
                                        <th style="text-align: center"><i class="fa-sharp fa-solid fa-boxes-packing"></i> Proveedor</th>
                                        <th style="text-align: center"><i class="fa-sharp fa-solid fa-arrows-to-eye"></i> Observaciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                            ';
                            while($tam = mysqli_fetch_array($evide)){
                            ?>
                            
                                <tr>
                                <td>
                                    <div class="col-md-12">
                                        <div class="form-group row">
                                            <div class="col-sm-12">
                                                <input name="idCo[]" type="hidden" class="form-control" value="<?php echo $idCo = $tam['idMateria'] ?>">
                                                <textarea name="mtu[]" id="mtu" rows="1" class="form-control" placeholder="Materia prima"><?php echo $matPri = $tam['matPri']?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td><!--Factura-->
                                    <div class="col-md-12">
                                        <div class="form-group row">
                                            <div class="col-sm-12">
                                                <select name="ftu[]" id="ftu" class="form-select">
                                                    <option value="<?php echo $fact = $tam['fact']?>"><?php echo $fact= $tam['fact']?></option>
                                                    <option value="Entregado">Entregado</option>
                                                    <option value="Falta">Falta</option>
                                                    <option value="NA">NA</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td><!--Proveedor 1-->
                                    <div class="col-md-12">
                                        <div class="form-group row">
                                            <div class="col-sm-12">
                                                <textarea name="pvu[]" id="pvu" rows="1" class="form-control" placeholder="Proveedor"><?php echo $provee = $tam['provee']?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td><!--Carta-->
                                    <div class="col-md-12">
                                        <div class="form-group row">
                                            <div class="col-sm-12">
                                                <select name="ctu[]" id="ctu" class="form-select">
                                                    <option value="<?php echo $carta = $tam['carta']?>"><?php echo $carta= $tam['carta']?></option>
                                                    <option value="Entregado">Entregado</option>
                                                    <option value="Falta">Falta</option>
                                                    <option value="NA">NA</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td><!--Proveedor 2-->
                                    <div class="col-md-12">
                                        <div class="form-group row">
                                            <div class="col-sm-12">
                                                <textarea name="pou[]" id="pou" rows="1" class="form-control" placeholder="Proveedor"><?php echo $proveed = $tam['proveed']?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td><!--Observaciones-->
                                    <div class="col-md-12">
                                        <div class="form-group row">
                                            <div class="col-sm-12">
                                                <textarea name="obu[]" id="obu" rows="1" class="form-control" placeholder="Observaciones"><?php echo $obs = $tam['obs'] ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php
                            }
                            echo '
                            </tbody>
                    </table>
                    <!--<div class="col-md-12">
                        <button type="button" class="btn btn-primary" id="addBtnEvide">Agregar</button>
                    </div>-->   
                            ';
                        }
                    ?>
                     
                </div>
                <div class="row">
                    <?php $ver = mysqli_query($conexion,"SELECT * FROM reproto WHERE codAle = '$codAle' "); 
                    $vers = mysqli_num_rows($ver);
                        if($vers > 0){
                            echo '
                            <h4 style="text-align: center; color:white;" class="bg-dark "><i class="fa-sharp fa-solid fa-user-magnifying-glass"></i> Revisión de prototipos</h4>
                            <table class="table" id="reviPro">
                                <thead class="thead-dark">
                                    <tr class="table-dark">
                                        <th style="text-align: center;"><i class="fa-sharp fa-solid fa-list-check"></i> Producto</th>
                                        <th style="text-align: center;"><i class="fa-sharp fa-solid fa-location-dot"></i> Lugar de uso</th>
                                        <th style="text-align: center;"><i class="fa-sharp fa-solid fa-ruler-combined"></i> Ancho de prototipo (cm)</th>
                                        <th style="text-align: center;"><i class="fa-sharp fa-solid fa-ruler-combined"></i> Medida Actual de logotipo (cm)</th>
                                        <th style="text-align: center;"><i class="fa-sharp fa-solid fa-ruler-combined"></i> Medida correcta de logotipo (cm)</th>
                                        <th style="text-align: center;"><i class="fa-sharp fa-solid fa-arrows-to-eye"></i> Observaciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                            ';
                            while($v = mysqli_fetch_array($ver)){
                                $idProt = $v['idProto'];
                                $prod = $v['prod'];
                                $lugar = $v['lugar'];
                                $ancho = $v['ancho'];
                                $medAct = $v['medAct'];
                                $medCor = $v['medCor'];
                                $obs = $v['obs'];
                                ?>
                                <tr>
                                    <td>
                                        <div class="col-md-12">
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                    <input type="hidden" name="idProt[]" value="<?php echo $idProt ?>">
                                                    <textarea name="rpu[]" id="rpu" rows="1" class="form-control" placeholder="Producto"><?php echo $prod ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><!--lugar de uso-->
                                        <div class="col-md-12">
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                    <select name="rlu[]" id="rlu" class="form-select">
                                                        <option value="<?php echo $lugar ?>"><?php echo $lugar ?></option>
                                                        <option value="Caja">Caja</option>
                                                        <option value="Etiqueta">Etiqueta</option>
                                                        <option value="Empaque">Empaque</option>
                                                        <option value="Costal">Costal</option>
                                                        <option value="Otro">Otro</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><!--Ancho prototipo-->
                                        <div class="col-md-12">
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                    <input id="rau" name="rau[]" type="number" class="form-control" step="0.01" value="<?php echo $ancho ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><!--Medida actual-->
                                        <div class="col-md-12">
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                    <input id="rmu" name="rmu[]" type="number" class="form-control" step="0.01" value="<?php echo $medAct ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><!--Medida correcta-->
                                        <div class="col-md-12">
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                    <input id="rluu" name="rluu[]" type="number" class="form-control" step="0.01" value="<?php echo $medCor ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><!--Observaciones-->
                                        <div class="col-md-12">
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                    <textarea name="rou[]" id="rou" rows="1" class="form-control"><?php echo $obs ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php
                            }
                            echo '
                            </tbody>
                    </table>
                            ';
                        }

                    ?>
                        <!--<div class="col-md-12">
                            <button type="button" class="btn btn-primary" id="revP">Agregar</button>
                        </div>-->                            
                </div>
                <div class="row">
                    <?php $supu = mysqli_query($conexion,"SELECT * FROM casupu WHERE codAle = '$codAle'");
                        $upus = mysqli_num_rows($supu);
                        if($upus > 0){
                            while($p = mysqli_fetch_array($supu)){
                                $idSupu = $p['idSupu'];
                                $carc = $p['carc'];
                                $carco = $p['carco'];
                                $camap = $p['camap'];
                                $camapo = $p['camapo'];
                                $propr = $p['propr'];
                                $propro = $p['propro'];
                                $pmarcp = $p['pmarcp'];
                                $pmarcpo = $p['pmarcpo'];
                            }
                        }
                    ?>
                    <div class="col-md-12">
                        <div class="form-group row">
                            <div class="col-sm-3">
                                <input type="hidden" name="idSupu" value="<?php echo $idSupu ?>">
                                <strong><label for="" class="form-label"><i class="fa-sharp fa-solid fa-envelope-open-text"></i> Carta supuesto a certificar</label></strong>
                            </div>
                            <div class="col-sm-4">
                                <select name="carc" id="" class="form-select">
                                    <option value="<?php echo $carc ?>"><?php echo $carc ?></option>
                                    <option value="Entregado">Entregado</option>
                                    <option value="En revisión">En revisión</option>
                                    <option value="Falta">Falta</option>
                                </select>
                            </div>
                            <div class="col-sm-5">
                                <textarea name="carco" id=""  rows="1"  class="form-control" placeholder="Observaciones"><?php echo $carco ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row">
                            <div class="col-sm-3">
                                <strong><label for="" class="form-label"><i class="fa-sharp fa-solid fa-envelope-open-text"></i> Carta marcado prototipo</label></strong>
                            </div>
                            <div class="col-sm-4">
                                <select name="camap" id="" class="form-select">
                                    <option value="<?php echo $camap ?>"><?php echo $camap ?></option>
                                    <option value="Entregado">Entregado</option>
                                    <option value="En revisión">En revisión</option>
                                    <option value="Falta">Falta</option>
                                </select>
                            </div>
                            <div class="col-sm-5">
                                <textarea name="camapo" id=""  rows="1"  class="form-control" placeholder="Observaciones"><?php echo $camapo ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row">
                            <div class="col-sm-3">
                                <strong><label for="" class="form-label"><i class="fa-sharp fa-solid fa-spinner"></i> Proceso de producción</label></strong>
                            </div>
                            <div class="col-sm-4">
                                <select name="propr" id="" class="form-select">
                                    <option value="<?php echo $propr ?>"><?php echo $propr ?></option>
                                    <option value="Entregado">Entregado</option>
                                    <option value="En revisión">En revisión</option>
                                    <option value="Falta">Falta</option>
                                </select>
                            </div>
                            <div class="col-sm-5">
                                <textarea name="propro" id=""  rows="1"  class="form-control" placeholder="Observaciones"><?php echo $propro ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row">
                            <div class="col-sm-3">
                                <strong><label for="" class="form-label"><i class="fa-sharp fa-solid fa-pen-to-square"></i> Marcado prototipo</label></strong>
                            </div>
                            <div class="col-sm-4">
                                <select name="pmarcp" id="" class="form-select">
                                    <option value="<?php echo $pmarcp ?>"><?php echo $pmarcp ?></option>
                                    <option value="Entregado">Entregado</option>
                                    <option value="En revisión">En revisión</option>
                                    <option value="Falta">Falta</option>
                                </select>
                            </div>
                            <div class="col-sm-5">
                                <textarea name="pmarcpo" id=""  rows="1"  class="form-control" placeholder="Observaciones"><?php echo $pmarcpo ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <strong><label for="" class="col-sm-6 col-form-label"><i class="fas fa-calendar-day"></i> Fecha de revisión documentación</label></strong>
                            <div class="col-sm-12">
                            <input type="date" class="form-control" id="revi" name="revi" value="<?php echo $revi ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <strong><label for="" class="col-sm-6 col-form-label"><i class="fas fa-calendar-day"></i> Fecha de visita</label></strong>
                            <div class="col-sm-12">
                                <input type="date" class="form-control" id="visi" name="visi" value="<?php echo $visi ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row">
                            <label for="" class="form-label lab"><i class="fa-sharp fa-solid fa-spinner"></i> Estatus del proceso</label>
                            <div class="col-sm-6">
                                <select name="estProc" id="estProc" class="form-select">
                                    <option value="<?php echo $estProc ?>"><?php echo $estProc ?></option>
                                    <option value="Firma del contrato">Firma del contrato</option>
                                    <option value="Revision documental">Revision documental</option>
                                    <option value="Auditoria en sitio">Auditoria en sitio</option>
                                    <option value="Finalizado">Finalizado</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div><br>
               

                <a href="../index.php" class="btn btn-danger"><i class="fas fa-undo"></i> Regresar</a>
                <button type="submit" class="btn btn-success"><i class="fas fa-check-circle"></i> Guardar</button>
            </form>
            <div class="col-md-6">
                <div class="form-group row">
                    <strong><label for="" class="col-sm-6 col-form-label"></label></strong>
                    <div class="col-sm-12">
                    </div>
                </div>
            </div>
        </div>
        <script src="segu.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
        
    </body>
</html>