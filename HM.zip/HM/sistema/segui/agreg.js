const btnTrami = document.querySelector('#btnTrami');
const tableBody = document.querySelector('#tramita tbody');

btnTrami.addEventListener('click', () => {
    const addRow = document.createElement('tr');
    addRow.innerHTML = `
        <td>
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                    <input type="text" class="form-control" id="tr1[]" name="tr1[]" placeholder="Tramitador" maxlength="100">
                    </div>
                </div>
            </div>
        </td>
        <td><!--Puesto-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                    <input type="text" class="form-control" id="pu1[]" name="pu1[]" placeholder="Puesto" maxlength="100">
                    </div>
                </div>
            </div>
        </td>
        <td><!--Telefono-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                    <input type="text" class="form-control" id="te1[]" name="te1[]" placeholder="Telefono" maxlength="15">
                    </div>
                </div>
            </div>
        </td>
        <td><!--correo-->
        <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                    <input type="text" class="form-control" id="co1[]" name="co1[]" placeholder="Correo" maxlength="100">
                    </div>
                </div>
            </div>
        </td>
    `;
    tableBody.appendChild(addRow);
});

const addBtnEvide = document.querySelector('#addBtnEvide');
const bodyEviden = document.querySelector('#eviden tbody');

addBtnEvide.addEventListener('click', () => {
    const addRow = document.createElement('tr');
    addRow.innerHTML = `
        <td>
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <textarea name="mtu[]" id="mtu" rows="1" class="form-control" placeholder="Materia Prima" maxlength="50"></textarea>
                    </div>
                </div>
            </div>
        </td>
        <td><!--Factura-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <select name="ftu[]" id="ftu" class="form-select">
                            <option value="Selecciona una opción">Selecciona una opción</option>
                            <option value="Entregado">Entregado</option>
                            <option value="Falta">Falta</option>
                            <option value="NA">NA</option>
                        </select>
                    </div>
                </div>
            </div>
        </td>
        <td><!--Proveedor 1-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <textarea name="pvu[]" id="pvu" rows="1" class="form-control" placeholder="Proveedor" maxlength="50"></textarea>
                    </div>
                </div>
            </div>
        </td>
        <td><!--Carta-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <select name="ctu[]" id="ctu" class="form-select">
                            <option value="Selecciona una opción">Selecciona una opción</option>
                            <option value="Entregado">Entregado</option>
                            <option value="Falta">Falta</option>
                            <option value="NA">NA</option>
                        </select>
                    </div>
                </div>
            </div>
        </td>
        <td><!--Proveedor 2-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <textarea name="pou[]" id="pou" rows="1" class="form-control" placeholder="Proveedor" maxlength="50"></textarea>
                    </div>
                </div>
            </div>
        </td>
        <td><!--Observaciones-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <textarea name="obu[]" id="obu" rows="1" class="form-control" placeholder="Observaciones" maxlength="50"></textarea>
                    </div>
                </div>
            </div>
        </td>
    `;
    bodyEviden.appendChild(addRow);
});

const revP = document.querySelector('#revP');
const bodyRev = document.querySelector('#reviPro tbody');

revP.addEventListener('click', () => {
    const addRow = document.createElement('tr');
    addRow.innerHTML = `
        <td>
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <textarea name="rpu[]" id="rpu[]" rows="1" class="form-control" placeholder="Producto" maxlength="50"></textarea>
                    </div>
                </div>
            </div>
        </td>
        <td><!--lugar de uso-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <select name="rlu[]" id="rlu" class="form-select">
                            <option value="Selecciona una opción">Selecciona una opción</option>
                            <option value="Caja">Caja</option>
                            <option value="Etiqueta">Etiqueta</option>
                            <option value="Empaque">Empaque</option>
                            <option value="Costal">Costal</option>
                            <option value="Otro">Otro</option>
                        </select>
                    </div>
                </div>
            </div>
        </td>
        <td><!--Ancho prototipo-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <input id="rau" name="rau[]" type="number" class="form-control" step="0.01" placeholder="00.00">
                    </div>
                </div>
            </div>
        </td>
        <td><!--Medida actual-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <input id="rmu" name="rmu[]" type="number" class="form-control" step="0.01" placeholder="00.00">
                    </div>
                </div>
            </div>
        </td>
        <td><!--Medida correcta-->
        <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <input id="rluu[]" name="rluu[]" type="number" class="form-control" step="0.01" placeholder="00.00">
                    </div>
                </div>
            </div>
        </td>
        <td><!--Observaciones-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <textarea name="rou[]" id="rou" rows="1" class="form-control" placeholder="Observaciones" maxlength="50"></textarea>
                    </div>
                </div>
            </div>
        </td>
    `;
    bodyRev.appendChild(addRow);
});

const btnFamP = document.querySelector('#btnFamP');
const divFam = document.querySelector('#famPr tbody');

btnFamP.addEventListener('click', () => {
    const aggDiv = document.createElement('tr');
    aggDiv.innerHTML=`
    
    <td>
    <div class="col-md-12">
        <div class="form-group row">
            <div class="col-sm-12">
                <input type="text" class="form-control" id="fami[]" name="fami[]" placeholder="Familia" maxlength="100">
            </div>
        </div>
    </div>
</td>
<td>
    <div class="col-md-12">
        <div class="form-group row">
            <div class="col-sm-12">
                <select name="pueF[]" id="pueF[]" class="form-select">
                    <option value="Supuesto 1">Supuesto 1</option>
                    <option value="Supuesto 2">Supuesto 2</option>
                    <option value="Supuesto 3">Supuesto 3</option>
                    <option value="Supuesto 4">Supuesto 4</option>
                </select>
            </div>
        </div>
    </div>
</td>
<td>
    <div class="col-md-12">
        <div class="form-group row">
            <div class="col-sm-12">
                <textarea name="modelo[]" id="modelo[]" class="form-control" rows="1" placeholder="Ingresa un modelo " maxlength="50"></textarea>
            </div>
        </div>
    </div>
</td>
    
    `;
    divFam.appendChild(aggDiv);
});