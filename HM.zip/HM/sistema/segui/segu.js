
const addBtnEvide = document.querySelector('#addBtnEvide');
const bodyEviden = document.querySelector('#eviden tbody');

addBtnEvide.addEventListener('click', () => {
    const addRow = document.createElement('tr');
    addRow.innerHTML = `
        <td>
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <textarea name="mtu[]" id="mtu" rows="1" class="form-control" placeholder="Materia Prima"></textarea>
                    </div>
                </div>
            </div>
        </td>
        <td><!--Factura-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <select name="ftu[]" id="ftu" class="form-select">
                            <option value="Selecciona una opción">Selecciona una opción</option>
                            <option value="Entregado">Entregado</option>
                            <option value="Falta">Falta</option>
                            <option value="NA">NA</option>
                        </select>
                    </div>
                </div>
            </div>
        </td>
        <td><!--Proveedor 1-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <textarea name="pvu[]" id="pvu" rows="1" class="form-control" placeholder="Proveedor"></textarea>
                    </div>
                </div>
            </div>
        </td>
        <td><!--Carta-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <select name="ctu[]" id="ctu" class="form-select">
                            <option value="Selecciona una opción">Selecciona una opción</option>
                            <option value="Entregado">Entregado</option>
                            <option value="Falta">Falta</option>
                            <option value="NA">NA</option>
                        </select>
                    </div>
                </div>
            </div>
        </td>
        <td><!--Proveedor 2-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <textarea name="pou[]" id="pou" rows="1" class="form-control" placeholder="Proveedor"></textarea>
                    </div>
                </div>
            </div>
        </td>
        <td><!--Observaciones-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <textarea name="obu[]" id="obu" rows="1" class="form-control" placeholder="Observaciones"></textarea>
                    </div>
                </div>
            </div>
        </td>
    `;
    bodyEviden.appendChild(addRow);
});

const revP = document.querySelector('#revP');
const bodyRev = document.querySelector('#reviPro tbody');

revP.addEventListener('click', () => {
    const addRow = document.createElement('tr');
    addRow.innerHTML = `
        <td>
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <textarea name="rpu[]" id="rpu[]" rows="1" class="form-control" placeholder="Producto"></textarea>
                    </div>
                </div>
            </div>
        </td>
        <td><!--lugar de uso-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <select name="rlu[]" id="rlu" class="form-select">
                            <option value="Selecciona una opción">Selecciona una opción</option>
                            <option value="Caja">Caja</option>
                            <option value="Etiqueta">Etiqueta</option>
                            <option value="Empaque">Empaque</option>
                            <option value="Costal">Costal</option>
                            <option value="Otro">Otro</option>
                        </select>
                    </div>
                </div>
            </div>
        </td>
        <td><!--Ancho prototipo-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <input id="rau" name="rau[]" type="number" class="form-control" step="0.01" placeholder="00.00">
                    </div>
                </div>
            </div>
        </td>
        <td><!--Medida actual-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <input id="rmu" name="rmu[]" type="number" class="form-control" step="0.01" placeholder="00.00">
                    </div>
                </div>
            </div>
        </td>
        <td><!--Medida correcta-->
        <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <input id="rlu" name="rlu[]" type="number" class="form-control" step="0.01" placeholder="00.00">
                    </div>
                </div>
            </div>
        </td>
        <td><!--Observaciones-->
            <div class="col-md-12">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <textarea name="rou[]" id="rou" rows="1" class="form-control" placeholder="Observaciones"></textarea>
                    </div>
                </div>
            </div>
        </td>
    `;
    bodyRev.appendChild(addRow);
});