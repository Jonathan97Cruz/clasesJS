<?php
require_once '../../conexion/conexion.php';
session_start();
if($_SESSION['active']!=true){
    session_destroy();
    header('location:../../index.php');
}
$conexion = conexion();
$idR = $_POST['idEmpre'];
/*Contrato */
$idContra = $_POST['idContra'];
$acta = $_POST['acta'];
$poder = $_POST['poder'];
$situacion = $_POST['situacion'];
$repre = $_POST['repre'];
$compro = $_POST['compro'];
$trami = $_POST['trami'];
$idTram = $_POST['idTram'];
$idTest = $_POST['idTest'];
$idTestD = $_POST['idTestD'];

$fecha = $_POST['fecha'];
/*Evaluacion */
$idEvalua = $_POST['idEvalua'];
$solSer = $_POST['solSer'];
$solSerO = $_POST['solSerO'];
$tablaM = $_POST['tablaM'];
$tablaMO = $_POST['tablaMO'];
$evideC = $_POST['evideC'];
$evideCO = $_POST['evideCO'];
$cartaS = $_POST['cartaS'];
$cartaSO = $_POST['cartaSO'];
$cartaM = $_POST['cartaM'];
$cartaMO = $_POST['cartaMO'];
$proceP = $_POST['proceP'];
$procePO = $_POST['procePO'];
$cartaP = $_POST['cartaP'];
$cartaPO = $_POST['cartaPO'];
$marcaP = $_POST['marcaP'];
$marcaPO = $_POST['marcaPO'];
$contraI = $_POST['contraI'];
$contraIO = $_POST['contraIO'];
$otroD = $_POST['otroD'];
$otroDO = $_POST['otroDO'];

$solici = $_POST['solici'];

/*  Evidencia de compra de materia prima */
$idCo = $_POST['idCo'];
$mtu = $_POST['mtu'];
$ftu = $_POST['ftu'];
$pvu = $_POST['pvu'];
$ctu = $_POST['ctu'];
$pou = $_POST['pou'];
$obu = $_POST['obu'];

/* Revisión de prototipos */
$idProt = $_POST['idProt'];
$rpu = $_POST['rpu'];
$rlu = $_POST['rlu'];
$rau = $_POST['rau'];
$rmu = $_POST['rmu'];
$rluu = $_POST['rluu'];
$rou = $_POST['rou'];


/**Ultima seccion */
$idSupu = $_POST['idSupu'];
$carc = $_POST['carc'];
$carco = $_POST['carco'];
$camap = $_POST['camap'];
$camapo = $_POST['camapo'];
$propr = $_POST['propr'];
$propro = $_POST['propro'];
$pmarcp = $_POST['pmarcp'];
$pmarcpo = $_POST['pmarcpo'];


$revi = $_POST['revi'];
$visi = $_POST['visi'];

$estProc = $_POST['estProc'];

$contrato = mysqli_query($conexion,"UPDATE `contrato` SET `acta`='$acta',`poder`='$poder',`situa`='$situacion',`repres`='$repre',
                                    `compro`='$compro',`trammi`='$trami',`idTram`='$idTram',`idTest`='$idTest',`idTestD`='$idTestD'
                                    WHERE idContra = $idContra ");
if($contrato == true){
    $evaluacion = mysqli_query($conexion,"UPDATE `evalua` SET `solSer`='$solSer',`solSerO`='$solSerO',`tablaM`='$tablaM',
                                    `tablaMO`='$tablaMO',`evideC`='$evideC',`evideCO`='$evideCO',`cartaS`='$cartaS',`cartaSO`='$cartaSO',
                                    `cartaM`='$cartaM',`cartaMO`='$cartaMO',`proceP`='$proceP',`procePO`='$procePO',`cartaP`='$cartaP',
                                    `cartaPO`='$cartaPO',`marcaP`='$marcaP',`marcaPO`='$marcaPO',`contraI`='$contraI',`contraIO`='$contraIO',
                                    `otroD`='$otroD',`otroDO`='$otroDO'
                                    WHERE idEvalua=$idEvalua ");
    if($evaluacion == true){
        for($i = 0; $i < count($idCo); $i++){
            $id = mysqli_real_escape_string($conexion, $idCo[$i]);
            $mt = mysqli_real_escape_string($conexion, $mtu[$i]);
            $ft = mysqli_real_escape_string($conexion, $ftu[$i]);
            $pv = mysqli_real_escape_string($conexion, $pvu[$i]);
            $ct = mysqli_real_escape_string($conexion, $ctu[$i]);
            $po = mysqli_real_escape_string($conexion, $pou[$i]);
            $ob = mysqli_real_escape_string($conexion, $obu[$i]);
            $query = mysqli_query($conexion,"UPDATE evcomp SET matPri = '$mt', fact = '$ft', provee = '$pv', carta = '$ct', proveed = '$po', obs = '$ob' WHERE idMateria = $id ");
        }
        if($query == true){
            for($a = 0; $a < count($idProt); $a++){
                $idPro = mysqli_real_escape_string($conexion, $idProt[$a]);
                $rp = mysqli_real_escape_string($conexion, $rpu[$a]);
                $rl = mysqli_real_escape_string($conexion, $rlu[$a]);
                $ra = mysqli_real_escape_string($conexion, $rau[$a]);
                $rm = mysqli_real_escape_string($conexion, $rmu[$a]);
                $ru = mysqli_real_escape_string($conexion, $rluu[$a]);
                $ro = mysqli_real_escape_string($conexion, $rou[$a]);
                $revision = mysqli_query($conexion, "UPDATE `reproto` SET `prod`='$rp',`lugar`='$rl',
                                                `ancho`=$ra,`medAct`=$rm,`medCor`=$ru,`obs`='$ro'
                                                WHERE `idProto`=$idPro");
            }
            
            if($revision == true){
                $ultimate = mysqli_query($conexion,"UPDATE `casupu` SET `carc`='$carc',`carco`='$carco',`camap`='$camap',
                                        `camapo`='$camapo',`propr`='$propr',`propro`='$propro',`pmarcp`='$pmarcp',`pmarcpo`='$pmarcpo'
                                        WHERE `idSupu`= $idSupu");
                if($ultimate == true){
                    $fech = mysqli_query($conexion,"UPDATE `registro` SET `fecContrato` = '$fecha', `fecSolicitud`='$solici',
                                                    `fecRevision` ='$revi', `fecVisita` = '$visi', `estProc` = '$estProc'
                                                    WHERE idR = $idR ");
                    if($fech == true){
                        $_SESSION['msj'] = "Actualizado correctamente";
                        header('location:../index.php');
                    }else{
                        $_SESSION['msg'] = "Error en linea 124";
                        header('location:../index.php');
                    }
                }else{
                    $_SESSION['msg'] = "Error en linea 123";
                    header('location:../index.php');
                }
            }else{
                $_SESSION['msg'] = "Error en linea 119";
                    header('location:../index.php');
            }
        }else{
            $_SESSION['msg'] = "Error en linea 105";
                    header('location:../index.php');
        }
    }else{
        $_SESSION['msg'] = "Error en linea 94";
                    header('location:../index.php');
    }
}else{
    $_SESSION['msg'] = "Error en linea 87";
                    header('location:../index.php');
}                 



?>